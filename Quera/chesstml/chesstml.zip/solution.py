import re as r


def process(got_Name):
    with open(got_Name, 'r', encoding='UTF-8') as file:
        a = r.findall("<a", file.read())

    a_count = 0
    for i in a:
        a_count += 1

    print(a_count)
    file.close()
    return a_count
